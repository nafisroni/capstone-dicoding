// import CONFIG from '../../globals/config';

const searchBarTemplate = () => `
    <div class="row mt-3">
      <div class="col-8 offset-2">
        <div class="row">
          <form class="d-flex p-1" role="search">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn orange btn-search" type="submit">Search</button>
          </form>
        </div>
      </div>
    </div>

`;

const categoryItemTemplate = () => `
<div class="card">
    <img src="#" class="card-img-top img-cate" alt="3">
    <div class="card-body">
    <div class="row">
        <h5 class="card-title">#</h5>
    </div>
    <div class="row">
        <button type="submit" class="btn orange">Jelajahi</button>
    </div>
    </div>
</div>
`;

const postItemTemplate = () => `
    <div class="card">
        <img src="../public/img-category/img-religi.jpg" class="card-img-top img-result" alt="Pemandangan Candi Borobudur">
        <div class="card-body row">
        <div class="col">
            <h6 class="card-title text-center">Wisata Religi</h6>
        </div>
        <div class="col">
            <h6 class="card-title text-center">Jakarta</h6>
        </div>
        </div>
    </div>
`;

export {
  categoryItemTemplate,
  searchBarTemplate,
  postItemTemplate,
};

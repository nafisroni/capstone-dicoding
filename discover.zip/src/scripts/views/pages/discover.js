const discover = {
  async render() {
    return `
    <section class="" id="searchbar">
        
    </section>
    <section class="" id="category">
    
    </section>
    <section class="" id="destination">
    
    </section>
    `;
  },

  async afterRender() {
    //
  },
};

export default discover;

import 'regenerator-runtime';
import '../styles/main.css';
import '../styles/responsive.css';

console.log('test');
